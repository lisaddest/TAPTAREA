/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreriafecha;

import javax.swing.JOptionPane;

/**
 *
 * @author gm_na
 */
public class DiaInvalido extends Exception{

    public DiaInvalido() {
    }

    public DiaInvalido(String msg) {
        super(msg);
    }
    
}
