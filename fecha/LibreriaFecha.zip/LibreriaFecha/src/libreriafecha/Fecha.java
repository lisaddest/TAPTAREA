/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreriafecha;

import javax.swing.JOptionPane;

/**
 *
 * @author gm_na
 */
public class Fecha {
    private int dia, mes, anio;

    public Fecha(int dia, int mes, int anio) throws DiaInvalido, MesInvalido{
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
        try{
            if (dia>31) {
            throw new DiaInvalido("DIA INVALIDO");
        }else if(mes>12){
            throw new MesInvalido("MES INVALIDO");
        }
            }catch(IllegalArgumentException e){
            
            JOptionPane.showMessageDialog(null, ""+e.getMessage());
        }
        }
        
    

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }
    
    public boolean isBisiesto(){
        return false;
    }
    
    public void restarSumarDias(int d){
        
    }
    
    public void restarSumarMeses(int m){
        
    }
    
    public void restarSumarAnios(int a){
        
    }

    @Override
    public String toString() {
        return "Fecha{" + "dia=" + dia + ", mes=" + mes + ", anio=" + anio + '}';
    }
    
    
}
