/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package appfecha;

import javax.swing.JOptionPane;
import libreriafecha.Fecha;
import libreriafecha.DiaInvalido;
import libreriafecha.MesInvalido;

/**
 *
 * @author gm_na
 */
public class AppFecha {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Fecha uno = new Fecha(31,17,2020);
            JOptionPane.showMessageDialog(null,uno);
        } catch (DiaInvalido | MesInvalido e) {
           JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }
    
}
